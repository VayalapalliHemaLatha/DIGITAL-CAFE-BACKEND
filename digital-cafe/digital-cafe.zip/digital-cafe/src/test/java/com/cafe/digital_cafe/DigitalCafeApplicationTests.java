package com.cafe.digital_cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
